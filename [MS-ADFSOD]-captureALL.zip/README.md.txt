1. Start Wireshark.
2. Select Edit -> Preferences.
3. Expand Protocols in the left column.
4. Find SSL in Protocols.
5. In the (Pre)-Master-Secret log filename, fill the path to the SSL key file.
  Use 
    MS-ADFSOD_SSLKeys_Example1.keys for MS-ADFSOD_Example1_Win10Sep2018_x64_WS2019Sep2018_X64_Domain.pcapng.
    MS-ADFSOD_SSLKeys_Example2.keys for MS-ADFSOD_Example2_Win10Sep2018_x64_WS2019Sep2018_X64_Domain.pcapng.
6. Open the pcapng file and the SSL/TLS packets should become plaintext.